﻿using System.Drawing;

namespace GameX4
{
    public static class PointExtension
    {
        public static Point IncrementX(this Point indexPoint, int value = 1)
        {
            return new Point(indexPoint.X + value, indexPoint.Y);
        }

        public static Point IncrementY(this Point indexPoint, int value = 1)
        {
            return new Point(indexPoint.X, indexPoint.Y + value);
        }

        public static bool IsInBound(this Point indexPoint, int maxX, int maxY, bool inclusive = false)
        {

            if (inclusive)
                return indexPoint.X <= maxX && indexPoint.Y <= maxY 
                    && indexPoint.X >= 0 && indexPoint.Y >= 0;
            return indexPoint.X < maxX && indexPoint.Y < maxY
                && indexPoint.X >= 0 && indexPoint.Y >= 0; 
        }
    }
}
