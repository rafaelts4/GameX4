﻿namespace GameX4
{
    public enum RotationDirection
    {
        Right, Left
    }

    public enum RelativePosition
    {
        Bellow = 0, ToTheRight = 1, Above = 2, ToTheLefet = 3
    }
}
