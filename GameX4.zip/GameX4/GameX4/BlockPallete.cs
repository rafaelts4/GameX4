﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace GameX4
{
    public class BlockPallete
    {
        private const int ALPHA_REGULAR = 225;
        private const int ALPHA_BRIGHT = 255;
        private const int ALPHA_DARK = 205;
        private static Random random = new Random();

        public static readonly Dictionary<int, Color> Regular = new Dictionary<int, Color>()
        {
            [0] = Color.FromArgb(ALPHA_REGULAR, 255, 026, 026),    //red       55%
            [1] = Color.FromArgb(ALPHA_REGULAR, 230, 230, 000),    //yellow    45%
            [2] = Color.FromArgb(ALPHA_REGULAR, 000, 230, 000),    //lime      45%
            [3] = Color.FromArgb(ALPHA_REGULAR, 026, 026, 255),    //blue      45%
            //[4] = Color.FromArgb(ALPHA_REGULAR, 230, 000, 172),    //magenta   45%
            //[5] = Color.FromArgb(ALPHA_REGULAR, 000, 230, 230),    //aqua      45%
        };

        public static Dictionary<int, Color> PickRandomColors(int value = 4)
        {
            var colors = new Dictionary<int, Color>(Regular);
            var picked = new Dictionary<int, Color>();
            for (int i = 0; i < value && colors.Count > 0; i++)
            {                
                var color = colors.ElementAt(random.Next(colors.Count));
                picked.Add(color.Key, color.Value);
                colors.Remove(color.Key);
            }
            return picked;
        }

        public static Color Brighten(int colorIndex)
        {
            return Brighten(Regular[colorIndex]);
        }
        public static Color Brighten(KeyValuePair<int, Color> paleteColor)
        {
            return Brighten(paleteColor.Value);
        }
        public static Color Brighten(Color baseColor)
        {
            return Color.FromArgb(ALPHA_BRIGHT, baseColor);
        }

        public static Color Darken(int colorIndex)
        {
            return Darken(Regular[colorIndex]);
        }

        public static Color Darken(KeyValuePair<int, Color> paleteColor)
        {
            return Darken(paleteColor.Value);
        }

        public static Color Darken(Color baseColor)
        {
            return Color.FromArgb(ALPHA_DARK, baseColor);
        }
    }
}
