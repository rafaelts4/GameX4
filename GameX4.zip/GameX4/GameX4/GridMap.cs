﻿using GameX4.VisualControllers;
using System.Collections.Generic;
using System.Drawing;

namespace GameX4
{
    public class GridMap
    {
        public Dictionary<Point, GridBlock> GridPoints { get; set; }

        public GridMap()
        {
            GridPoints = new Dictionary<Point, GridBlock>();
        }

        public GridMap(int capacity)
        {
            GridPoints = new Dictionary<Point, GridBlock>(capacity);
        }

        public GridBlock this[int row, int column]
        {
            get
            {
                return GridPoints[new Point(row, column)];
            }
            set
            {
                GridPoints[new Point(row, column)] = value;
            }
        }

        public GridBlock this[Point point]
        {
            get
            {
                return GridPoints[point];
            }
            set
            {
                GridPoints[point] = value;
            }
        }

        public bool HasBlock(Point indexPoint)
        {
            return GridPoints.ContainsKey(indexPoint)
                && GridPoints[indexPoint].Block != null;
        }

        public GridBlock GetNeighborBlockFrom(Point indexPoint, RelativePosition positionOfNextBlock)
        {
            if (!GridPoints.ContainsKey(indexPoint))
                return null;
            Point neighborIndexPoint;
            switch (positionOfNextBlock)
            {
                case RelativePosition.Bellow:
                    neighborIndexPoint = indexPoint.IncrementY();
                    break;
                case RelativePosition.ToTheRight:
                    neighborIndexPoint = indexPoint.IncrementX();
                    break;
                case RelativePosition.Above:
                    neighborIndexPoint = indexPoint.IncrementY(-1);
                    break;
                case RelativePosition.ToTheLefet:
                    neighborIndexPoint = indexPoint.IncrementX(-1);
                    break;
                default: return null;
            }
            if (!GridPoints.ContainsKey(neighborIndexPoint))
                return null;
            return GridPoints[neighborIndexPoint];
        }
    }

    public class GridBlock
    {
        public GridBlock(Point location, Block block)
        {
            Location = location;
            Block = block;
        }

        public GridBlock(Point location) : this(location, null) { }

        public GridBlock(int x, int y) : this(new Point(x, y)) { }

        public Point Location { get; set; }

        public Block Block { get; set; }
    }   
}
