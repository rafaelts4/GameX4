﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace GameX4.VisualControllers
{
    public partial class Block : UserControl
    {
        private BlocksGrid grid;
        private PointF p1, p2, p3, p4, p5;
        private static Pen blackPen = new Pen(Color.Black, 2);
        private static Pen whitePen = new Pen(Color.White, 2);

        public event Action<Block> Settled;
        public event Action<Block> BecameSubmissive;

        public List<KeyValuePair<int, Color>> Sections { get; set; }
        public Point IndexPoint { get; private set; }
        public bool IsSettled { get; private set; }
        public bool IsSubmissive { get; private set; }
        public bool IsFloating
        {
            get
            {
                if (grid == null)
                    return (Location.Y + Size.Height) < Parent.Height;
                if (IndexPoint.Y >= grid.RowsUpperBound)
                    return false;
                return BlockUnder?.Block == null;
            }
        }

        public GridBlock BlockUnder
        {
            get
            {
                if (IndexPoint.Y >= grid.RowsUpperBound)
                    return null;
                return grid.Map[IndexPoint.IncrementY()];
            }
        }
        public GridBlock BlockOver
        {
            get
            {
                if (IndexPoint.Y <= 0)
                    return null;
                return grid.Map[IndexPoint.IncrementY(-1)];
            }
        }
        public GridBlock BlockRight
        {
            get
            {
                if (IndexPoint.X >= grid.ColumnsUpperBound)
                    return null;
                return grid.Map[IndexPoint.IncrementX()];
            }
        }
        public GridBlock BlockLeft
        {
            get
            {
                if (IndexPoint.X <= 0)
                    return null;
                return grid.Map[IndexPoint.IncrementX(-1)];
            }
        }

        public Block()
        {
            InitializeComponent();
            Sections = BlockPallete.PickRandomColors().ToList();
        }

        public Block(BlocksGrid grid, Point indexPoint) : this()
        {
            this.grid = grid;
            IndexPoint = indexPoint;
            Location = this.grid.Map[indexPoint].Location;
        }

        public bool MoveTo(Point newIndexPoint)
        {
            if (IsSettled || IndexPoint == newIndexPoint)
                return false;
            if (!newIndexPoint.IsInBound(grid.Rows, grid.Columns))
                return false;
            if (grid.Map.HasBlock(newIndexPoint))
                return false;
            var block = grid.Map[IndexPoint].Block;
            grid.Map[IndexPoint].Block = null;
            IndexPoint = newIndexPoint;
            grid.Map[newIndexPoint].Block = block;
            Location = grid.Map[newIndexPoint].Location;
            return true;
        }

        public bool MoveLeft()
        {
            return MoveTo(IndexPoint.IncrementX(-1));
        }

        public bool MoveRight()
        {
            return MoveTo(IndexPoint.IncrementX());
        }

        public void Rotate(RotationDirection direction)
        {
            var newSections = new List<KeyValuePair<int, Color>>();
            if (direction == RotationDirection.Left)
            {                
                newSections.Add(Sections.Last());
                for (int i = 0; i < Sections.Count - 1; i++)
                    newSections.Add(Sections.ElementAt(i));
            }
            else
            {
                for (int i = 1; i < Sections.Count; i++)
                    newSections.Add(Sections.ElementAt(i));
                newSections.Add(Sections.First());
            }
            Sections = newSections;
            Refresh();
        }

        public bool Fall()
        {
            if (!IsFloating)
                return false;
            return MoveTo(IndexPoint.IncrementY());
        }

        public bool SubdueTo(KeyValuePair<int, Color> color)
        {
            if (IsSubmissive)
                return false;
            for (int i = 0; i < 4; i++)
            {
                Sections[i] = color;
            }
            IsSubmissive = true;
            BecameSubmissive?.Invoke(this);
            Refresh();
            return true;
        }

        public void Brighten(RelativePosition? position)
        {
            if (position == null)
            {
                for (int i = 0; i < 4; i++)
                {
                    var key = Sections[i].Key;
                    var brightColor = BlockPallete.Brighten(key);
                    Sections[i] = new KeyValuePair<int, Color>(key, brightColor);
                }
            }
            else
            {
                var key = Sections[(int)position].Key;
                var brightColor = BlockPallete.Brighten(key);
                Sections[(int)position] = new KeyValuePair<int, Color>(key, brightColor);
            }
        }        

        private void Block_LocationChanged(object sender, EventArgs e)
        {
            if (IsFloating)
                return;
            IsSettled = true;
            Settled?.Invoke(this);
#if DEBUG
            CaptureFormImage();
#endif
            Refresh();
        }

        private void Block_Load(object sender, EventArgs e)
        {   /*------------
             |1    c    2|  a -> 345
             |   \   /   |  b -> 235
             |d    5    b|  c -> 125
             |   /   \   |  d -> 145 
             |4    a    3|             
             -------------*/
            p1 = new PointF(0, 0);
            p2 = new PointF(Width, 0);
            p3 = new PointF(Width, Height);
            p5 = new PointF(Height / 2, Width / 2);
            p4 = new PointF(0, Height);
        }

        private void Block_Paint(object sender, PaintEventArgs e)
        {
            var drawTriangle = new Action<Color, PointF, PointF, PointF>((color, P1, P2, P3)
                => e.Graphics.FillPolygon(new SolidBrush(color), new PointF[] { P1, P2, P3 })
            );
            if (IsSettled)
            {
                drawTriangle(BlockPallete.Darken(Sections.ElementAt(0)), p3, p4, p5);
                drawTriangle(BlockPallete.Darken(Sections.ElementAt(1)), p2, p3, p5);
                drawTriangle(BlockPallete.Darken(Sections.ElementAt(2)), p1, p2, p5);
                drawTriangle(BlockPallete.Darken(Sections.ElementAt(3)), p1, p4, p5);
            }
            else
            {
                drawTriangle(Sections.ElementAt(0).Value, p3, p4, p5);
                drawTriangle(Sections.ElementAt(1).Value, p2, p3, p5);
                drawTriangle(Sections.ElementAt(2).Value, p1, p2, p5);
                drawTriangle(Sections.ElementAt(3).Value, p1, p4, p5);
            }
            if (!IsSubmissive)
            {
                var pen = (IsSettled) ? blackPen : whitePen;
                e.Graphics.DrawLine(pen, p1, p3);
                e.Graphics.DrawLine(pen, p2, p4);
            }
        }
#if DEBUG
        public void CaptureFormImage()
        {
            Bitmap image = new Bitmap(ParentForm.Width, ParentForm.Height);
            ParentForm.DrawToBitmap(image, new Rectangle(new Point(0, 0), image.Size));
            image.Save($"img{DateTime.Now.ToString("ddMMyyyy.HHmmssfff")}.bmp");
        }
#endif        
    }
}
