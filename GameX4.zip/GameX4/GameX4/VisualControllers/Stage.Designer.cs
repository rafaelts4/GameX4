﻿namespace GameX4.VisualControllers
{
    partial class Stage
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlStage = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // pnlStage
            // 
            this.pnlStage.BackColor = System.Drawing.Color.White;
            this.pnlStage.ForeColor = System.Drawing.Color.White;
            this.pnlStage.Location = new System.Drawing.Point(26, 63);
            this.pnlStage.Name = "pnlStage";
            this.pnlStage.Size = new System.Drawing.Size(400, 400);
            this.pnlStage.TabIndex = 1;
            // 
            // Stage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(520, 500);
            this.ControlBox = false;
            this.Controls.Add(this.pnlStage);
            this.Name = "Stage";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Stage";                        
            this.Controls.SetChildIndex(this.pnlStage, 0);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlStage;
    }
}

