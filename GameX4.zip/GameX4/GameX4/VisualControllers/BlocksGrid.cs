﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameX4.VisualControllers
{
    public partial class BlocksGrid : UserControl
    {
        public int Rows { get; private set; }
        public int RowsUpperBound { get { return Rows - 1; } }
        public int Columns { get; private set; }
        public int ColumnsUpperBound { get { return Columns - 1; } }
        public Block FallingBlock { get; private set; }
        public GridMap Map { get; private set; }
        public int RowsHeight { get { return Height / Rows; } }
        public int ColumnsWidth { get { return Width / Columns; } }

        public BlocksGrid(int rows, int columns)
        {
            InitializeComponent();
            Rows = rows;
            Columns = columns;
            Map = new GridMap(Rows * Columns);
        }

        public BlocksGrid() : this(10, 10) { }

        #region Events
        private void BlocksGrid_Paint(object sender, PaintEventArgs e)
        {
            DrawCheckeredPattern(e.Graphics);
            //DrawGridLines(e.Graphics);
            ControlPaint.DrawBorder(e.Graphics, ClientRectangle, Color.Orange, ButtonBorderStyle.Solid);
        }

        private void BlocksGrid_Load(object sender, EventArgs e)
        {
            LoadGridPoints();
            CreateNewBlock();
            tmrGravidade.Start();
        }

        private void tmrGravidade_Tick(object sender, EventArgs e)
        {
            FallingBlock?.Fall();
        }
        #endregion

        #region Methods              

        private void CreateNewBlock()
        {
            var point = new Point(Columns / 2, 0);
            var block = new Block(this, point);
            block.Size = new Size(RowsHeight, ColumnsWidth);
            Map[point].Block = FallingBlock = block;
            block.Settled += Block_Settled;
            Controls.Add(FallingBlock);
        }

        private async void Block_Settled(Block sender)
        {
            await Disseminate(sender.IndexPoint);
            //TODO: MAKE FLOATING BLOCKS FALL.            
            for (int row = RowsUpperBound - 1; row >= 0; row--)
            {
                for (int col = ColumnsUpperBound - 1; col >= 0; col--)
                {
                    Map[col, row]?.Block?.Fall();
                }
            }
            Refresh();
            CreateNewBlock();
        }

        private void DrawGridLines(Graphics graphics)
        {
            var pen = new Pen(Color.Black, 1);
            var columnWidth = ColumnsWidth;
            var rowHeight = RowsHeight;
            for (int r = 1; r < Rows; r++)
            {
                var x = columnWidth * r;
                graphics.DrawLine(pen, new Point(0, x), new Point(Width, x));
            }

            for (int c = 1; c < Columns; c++)
            {
                var y = rowHeight * c;
                graphics.DrawLine(pen, new Point(y, 0), new Point(y, Height));
            }
        }

        private void DrawCheckeredPattern(Graphics graphics)
        {
            var darkBrush = new SolidBrush(Color.LightGray);
            var size = new Size(ColumnsWidth, RowsHeight);
            for (int r = 0; r < Rows; r++)
            {
                for (int c = 0; c < Rows; c++)
                {
                    if ((r + c) % 2 == 0)
                    {
                        graphics.FillRectangle(darkBrush, new Rectangle(Map[r, c].Location, size));
                    }
                }
            }
        }

        private void LoadGridPoints()
        {
            for (int r = 0; r < Rows; r++)
            {
                var x = r * RowsHeight;
                for (int c = 0; c < Columns; c++)
                {
                    var y = c * ColumnsWidth;
                    Map[r, c] = new GridBlock(x, y);
                }
            }
        }

        public async Task Disseminate(Point startIndexPoint)
        {
            tmrGravidade.Stop();
            var blocksToRemove = new Dictionary<Point, GridBlock>();
            for (int r = 0; r < Rows; r++)
            {
                for (int c = 0; c < Columns; c++)
                {
                    var indexPoint = new Point(r, c);
                    if (Map[indexPoint].Block == null)
                        continue;
                    for (int i = 0; i < 4; i++)
                    {
                        if (await SubdueBlocks(indexPoint, (RelativePosition)i))
                        {
                            Map[indexPoint].Block.Brighten((RelativePosition)i);
                            Map[indexPoint].Block.Refresh();
                            await Task.Delay(100);
                            if (blocksToRemove.ContainsKey(indexPoint))
                                blocksToRemove[indexPoint] = Map[indexPoint];
                            else
                                blocksToRemove.Add(indexPoint, Map[indexPoint]);
                            var neighbor = Map.GetNeighborBlockFrom(indexPoint, (RelativePosition)i);
                            if (blocksToRemove.ContainsKey(neighbor.Block.IndexPoint))
                                blocksToRemove[neighbor.Block.IndexPoint] = neighbor;
                            else
                            {
                                blocksToRemove.Add(neighbor.Block.IndexPoint, neighbor);
                            }
                        }
                    }
                }
            }
            foreach (var blockToRemove in blocksToRemove)
            {
                Controls.Remove(blockToRemove.Value.Block);
                Map[blockToRemove.Key].Block = null;
            }
            Refresh();
            tmrGravidade.Start();
        }

        public async Task<bool> SubdueBlocks(Point origin, RelativePosition position)
        {
            var color = GetColorMatch(origin, position);
            if (color == null)
                return false;
            Block neighbor = Map.GetNeighborBlockFrom(origin, position)?.Block;
            if (neighbor == null || neighbor.IsSubmissive)
                return false;
            neighbor.SubdueTo(color.Value);
            Map[origin].Block.SubdueTo(color.Value);
            await Task.Delay(100);
            Refresh();
            return true;
        }

        public KeyValuePair<int, Color>? GetColorMatch(Point indexPoint, RelativePosition positionOfNextBlock)
        {
            var reference = Map[indexPoint]?.Block;
            if (reference == null)
                return null;

            var neighbor = Map.GetNeighborBlockFrom(indexPoint, positionOfNextBlock)?.Block;
            if (reference == null || neighbor == null)
                return null;

            int idxColorNeighbor = ((int)positionOfNextBlock + 2) % 4;
            if (reference.Sections[(int)positionOfNextBlock].Key == neighbor.Sections[idxColorNeighbor].Key)
                return neighbor.Sections[idxColorNeighbor];

            return null;
        }
        #endregion
    }
}