﻿using System.Windows.Forms;

namespace GameX4.VisualControllers
{
    public partial class Stage : DraggableForm
    {
        private BlocksGrid player1Grid;
        public Stage()
        {
            InitializeComponent();
            player1Grid = new BlocksGrid(8, 8);
            pnlStage.Controls.Add(player1Grid);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Left || keyData == Keys.A || keyData == Keys.NumPad4)
            {
                player1Grid.FallingBlock?.MoveLeft();
            }
            else if (keyData == Keys.Right || keyData == Keys.D || keyData == Keys.NumPad6)
            {
                player1Grid.FallingBlock?.MoveRight();
            }
            else if (keyData == Keys.Down || keyData == Keys.S || keyData == Keys.NumPad5)
            {
                player1Grid.FallingBlock?.Fall();
            }
            else if (keyData == Keys.Space || keyData == Keys.C || keyData == Keys.NumPad3) 
            {
                player1Grid?.FallingBlock?.Rotate(RotationDirection.Right);
            }
            else if (keyData == Keys.X || keyData == Keys.Z || keyData == Keys.NumPad1)
            {
                player1Grid?.FallingBlock?.Rotate(RotationDirection.Left);
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
