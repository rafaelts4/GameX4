﻿namespace GameX4.VisualControllers
{
    partial class BlocksGrid
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrGravidade = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // tmrGravidade
            // 
            this.tmrGravidade.Interval = 1000;
            this.tmrGravidade.Tick += new System.EventHandler(this.tmrGravidade_Tick);
            // 
            // BlocksGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "BlocksGrid";
            this.Size = new System.Drawing.Size(400, 400);
            this.Load += new System.EventHandler(this.BlocksGrid_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.BlocksGrid_Paint);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrGravidade;
    }
}
