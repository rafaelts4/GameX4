﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GameX4.VisualControllers
{
    public partial class DraggableForm : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        public DraggableForm()
        {
            InitializeComponent();
        }

        private void pnlTop_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void lblClose_Click(object sender, EventArgs e)
        {            
            Close();
        }

        private void lblClose_MouseHover(object sender, EventArgs e)
        {
            var font = new Font(lblClose.Font, FontStyle.Bold);            
            lblClose.Font = font;
        }

        private void lblClose_MouseLeave(object sender, EventArgs e)
        {
            var font = new Font(lblClose.Font, FontStyle.Regular);
            lblClose.Font = font;
        }

        private void DraggableForm_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            e.IsInputKey = true;
        }
    }
}
